# KickMyB-Library
Common classes for KickMyB
