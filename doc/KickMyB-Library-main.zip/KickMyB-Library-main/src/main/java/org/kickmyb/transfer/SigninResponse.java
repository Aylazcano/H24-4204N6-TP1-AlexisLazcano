package org.kickmyb.transfer;

public class SigninResponse {
    public String username;     // username dans un format propre produit par le serveur
}
