package org.kickmyb.transfer;

// requête de connexion au serveur, ce sont les mêmes champs qu'une inscription
public class SigninRequest extends SignupRequest {
}
