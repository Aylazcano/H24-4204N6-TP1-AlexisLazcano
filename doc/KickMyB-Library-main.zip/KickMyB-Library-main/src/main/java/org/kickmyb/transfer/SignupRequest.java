package org.kickmyb.transfer;

public class SignupRequest {

    public String username;
    public String password;
}
